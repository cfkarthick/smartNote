import { Component, OnInit } from '@angular/core';
import { IonicNativePlugin } from '@ionic-native/core';
import { Camera,CameraOptions  } from '@ionic-native/camera/ngx';
import { ActionSheetController, ToastController, Platform, LoadingController, } from '@ionic/angular';
import {AngularFireStorage,AngularFireStorageReference,AngularFireUploadTask} from '@angular/fire/storage'

import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer/ngx';


const STORAGE_KEY = 'my_images';

@Component({
  selector: 'app-create-marker',
  templateUrl: './create-marker.page.html',
  styleUrls: ['./create-marker.page.scss'],
})
export class CreateMarkerPage implements OnInit {
  
  imageFileName:any='';
  
  
  constructor(
    public camera: Camera,
    public INP:IonicNativePlugin,
    
   
    public FT:FileTransfer,
    public FTO : FileTransferObject,
    public loadingCtrl:LoadingController,
    
    
   
   

  ) { }

  ngOnInit() {
   

   
  }
  

  async uploadFile() {
    const loadingController = document.querySelector('ion-loading-controller');
    await loadingController.componentOnReady();
    let loader = await this.loadingCtrl.create({
      message: "Uploading...",
      spinner: 'crescent',
      duration: 2000
    })
    loader.present();
    const fileTransfer: FileTransferObject = this.FT.create();
  
    let options: FileUploadOptions = {
      fileKey: 'ionicfile',
      fileName: 'ionicfile',
      chunkedMode: false,
      mimeType: "image/jpeg",
      headers: {}
    }

    //var rootRef = this.AFS.storage.ref().child('')
  }

 
 
async takePicture(type) {
  const loadingController = document.querySelector('ion-content');
    await loadingController.componentOnReady();
    let loader = await this.loadingCtrl.create({
      message: "Please wait",
      spinner: 'crescent',
      duration: 2000
    })
    loader.present();
    var source = this.camera.PictureSourceType.PHOTOLIBRARY
  if(type==='cam'){
    source = this.camera.PictureSourceType.CAMERA;
  }
    var camOptions: CameraOptions = {
        quality: 70,
        destinationType:this.camera.DestinationType.DATA_URL,
        sourceType: source,
        saveToPhotoAlbum:false
        
      };
 
    this.camera.getPicture(camOptions).then((imageData) => {
       // this.imageFileName='data:image/jpeg;base64,'+imageData;
       this.imageFileName = this.buildMarker()
    });
 
}
private buildMarker(){
debugger;
  var whiteMargin = 0.1,
  blackMargin = (1 - 2 * whiteMargin) * ((1-0.9)/2),
  innerMargin = whiteMargin + blackMargin,
  canvas = document.createElement('canvas'),
  context = canvas.getContext('2d')
  
  canvas.width =  270;
  canvas.height = 350;

  context.fillStyle = 'black';
	context.fillRect(
		whiteMargin * canvas.width,
		whiteMargin * canvas.height,
		canvas.width * (1-2*whiteMargin),
		canvas.height * (1-2*whiteMargin)
  );
  
  context.fillStyle = 'white';
	context.fillRect(
		innerMargin * canvas.width,
		innerMargin * canvas.height,
		canvas.width * (1-2*innerMargin),
		canvas.height * (1-2*innerMargin)
	);

  var innerImage = document.createElement('img')
	innerImage.addEventListener('load', function(){
		// draw innerImage
		context.drawImage(innerImage,
			innerMargin * canvas.width,
			innerMargin * canvas.height,
			canvas.width * (1-2*innerMargin),
			canvas.height * (1-2*innerMargin)
		);

		
		
	})
	return canvas.toDataURL()

}


}

  
